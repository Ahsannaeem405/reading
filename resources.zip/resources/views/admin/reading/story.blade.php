@extends('admin.layouts.main')
@section('content')

    <section id="column-selectors">
        <div class="row" >

            <div class="col-12">
                <div class="row">
                </div>
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Stories</h4>
                      <a href="{{url('admin/readings/story/add')}}">  <input type="button" class="btn btn-primary" value="ADD"></a>
                    </div>


                    <div class="card-content">
                        <div class="card-body card-dashboard">

                            <div class="table-responsive">
                                <table class="table table-striped dataex-html5-selectors">

                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Picture</th>
                                        <th>Name</th>
                                        <th>Questions</th>
                                        <th>Writer</th>


                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td><img style="width: 100px;height: 50px" src="{{asset('userSide/assets/img/logo/logo.png')}}"></td>
                                        <td>XYZ</td>
                                        <td>5</td>
                                        <td>Rehman</td>


                                        <td><a><i style="color: blue;font-size: 20px" class="fa fa-edit"></i></a><a><i style="color: red;font-size: 20px"  class="fa fa-trash p-2"></i></a></td>
                                    </tr>


                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


@endsection
