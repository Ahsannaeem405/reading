@extends('admin.layouts.main')

@section('content')

    <section id="validation">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Add Teacher </h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form action="#" class="steps-validation wizard-circle">
                                <!-- Step 1 -->
                                <h6><i class="step-icon feather icon-home"></i> Personal Information</h6>
                                <fieldset>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="firstName3">
                                                    First Name
                                                </label>
                                                <input type="text" class="form-control required" id="firstName3" name="firstName">
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="lastName3">
                                                    Last Name
                                                </label>
                                                <input type="text" class="form-control required" id="lastName3" name="lastName">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="emailAddress5">
                                                    Email
                                                </label>
                                                <input type="email" class="form-control required" id="emailAddress5" name="emailAddress">
                                            </div>
                                        </div>


                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="emailAddress67">
                                                    phone
                                                </label>
                                                <input type="number" class="form-control required" id="emailAddress67" name="phone">
                                            </div>
                                        </div>


                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="age">
                                                    Age
                                                </label>
                                                <input type="number" class="form-control required" id="age" name="age">
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="location">
                                                    City
                                                </label>
                                                <select class="custom-select form-control" id="location" name="location">
                                                    <option value="">New York</option>
                                                    <option value="Amsterdam">Chicago</option>
                                                    <option value="Berlin">San Francisco</option>
                                                    <option value="Frankfurt">Boston</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>

                                <!-- Step 2 -->
                                <h6><i class="step-icon feather icon-briefcase"></i> Profile Information</h6>
                                <fieldset>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="proposalTitle3">
                                                    Proposal Title
                                                </label>
                                                <input type="text" class="form-control required" id="proposalTitle3" name="proposalTitle">
                                            </div>
                                            <div class="form-group">
                                                <label for="jobTitle5">
                                                    Job Title
                                                </label>
                                                <input type="text" class="form-control required" id="jobTitle5" name="jobTitle">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="shortDescription3">Short Description</label>
                                                <textarea name="shortDescription" id="shortDescription3" rows="4" class="form-control"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>

                                <!-- Step 3 -->

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


@endsection
