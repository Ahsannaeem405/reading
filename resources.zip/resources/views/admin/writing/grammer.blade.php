@extends('admin.layouts.main')

@section('content')

    <main>



        <div id="fill_1"  class="col-md-12 col-12">
            <div class="card" style="height: auto">
                <div class="card-header">
                    <h4 class="card-title">Fill in the Blank Question </h4>
                </div>
                <h4 class="card-title text-center mt-2 mb-1">TOP HEADING</h4>
<div class="container-fluid">
<div class="row">
    <div  class="col-lg-12">
                <input type="text" class="form-control" placeholder="Top heading">
</div>
</div>
</div>
    <div class="card-content">
                    <div class="card-body">
                        <form class="form form-horizontal">
                            <div class="form-body">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group row">
                                            <div class="col-md-4">
                                                <span>Question part 1</span>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" id="first-name" class="form-control" name="question" placeholder="Please Enter Question...">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-4">
                                                <span>Question part 2</span>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" id="first-name" class="form-control" name="question" placeholder="Please Enter Question...">
                                            </div>
                                        </div>


                                        <div class="form-group row">
                                            <div class="col-md-4">
                                                <span>Question part 3</span>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" id="first-name" class="form-control" name="question" placeholder="Please Enter Question...">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group row">
                                            <div class="col-md-4">

                                                <span>Which one use as fill in the blank</span>

                                            </div>
                                            <div class="col-md-8">

                                                <select   class="form-control" name="email-id" >
                                                    <option>Please Select</option>
                                                    <option>Question part 1</option>
                                                    <option>Question part 2</option>
                                                    <option>Question part 3</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="col-md-8 offset-md-4">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1 waves-effect waves-light">Submit</button>
                                        <button type="reset" class="btn btn-outline-warning mr-1 mb-1 waves-effect waves-light">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

@endsection
