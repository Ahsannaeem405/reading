@extends('userSide.layouts.main')

@section('content')



    <main>


        <div class="slider-area">
            <div class="slider-height2 d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap hero-cap2 text-center">
                                <h2>Students</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



<div class="container">


    <table class="table mt-5 mb-5 pt-5 pb-5">
        <thead class="thead-light">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Phone</th>
            <th scope="col">New Reports</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>xyz@gmail.com</td>
            <td>000000000</td>
            <td><div style="background-color: greenyellow;width: 25px;height: 25px;border-radius: 50%;color: white;text-align: center;"><span>0</span></div></td>
            <td><a href="{{url('teacher/student/report')}}"> <input type="button" class="btn btn-success p-3" style="border-radius: 5px" value="View Report" ></a></td>
        </tr>



        <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>xyz@gmail.com</td>
            <td>000000000</td>
            <td><div style="background-color: red;width: 25px;height: 25px;border-radius: 50%;color: white;text-align: center;"><span>2</span></div></td>
            <td><a href="{{url('teacher/student/report')}}"> <input type="button" class="btn btn-success p-3" style="border-radius: 5px" value="View Report" ></a></td>
        </tr>





        <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>xyz@gmail.com</td>
            <td>000000000</td>
            <td><div style="background-color: red;width: 25px;height: 25px;border-radius: 50%;color: white;text-align: center;"><span>2</span></div></td>
            <td><a href="{{url('teacher/student/report')}}"> <input type="button" class="btn btn-success p-3" style="border-radius: 5px" value="View Report" ></a></td>
        </tr>




        <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>xyz@gmail.com</td>
            <td>000000000</td>
            <td><div style="background-color: red;width: 25px;height: 25px;border-radius: 50%;color: white;text-align: center;"><span>2</span></div></td>
            <td><a href="{{url('teacher/student/report')}}"> <input type="button" class="btn btn-success p-3" style="border-radius: 5px" value="View Report" ></a></td>
        </tr>





        </tbody>
    </table>

</div>
        </div>






    </main>
    @endsection
