@extends('userSide.layouts.main')

@section('content')
    <main>
        <!--? Hero Start -->
        <div class="slider-area">
            <div class="slider-height2 d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap hero-cap2 text-center">
                                <h2>Topics</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="count-down-area pt-90 pb-60 section-bg" data-background="{{asset('userSide/assets/img/gallery/section_bg01.png')}}">
            <div class="container">

                <div class="col-lg-12 col-md-12">

                    <div class="row ">

<div class="col-lg-4 mb-4">



    <div class="card" style="width: 18rem;">
        <img class="card-img-top" src="{{asset('userSide/assets/img/blog/slide_thumb_1.png')}}" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title">Topic title</h5>
            <p class="card-text">Short description about the topic.</p>
            <a href="{{url('writing/topics/1')}}" class="btn btn-primary">Select</a>
        </div>
    </div>

</div>


                        <div class="col-lg-4 mb-4">



                            <div class="card" style="width: 18rem;">
                                <img class="card-img-top" src="{{asset('userSide/assets/img/blog/slide_thumb_1.png')}}" alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title">Topic title</h5>
                                    <p class="card-text">Short description about the topic.</p>
                                    <a href="{{url('writing/topics/1')}}" class="btn btn-primary">Select</a>
                                </div>
                            </div>

                        </div>



                        <div class="col-lg-4 mb-4">



                            <div class="card" style="width: 18rem;">
                                <img class="card-img-top" src="{{asset('userSide/assets/img/blog/slide_thumb_1.png')}}" alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title">Topic title</h5>
                                    <p class="card-text">Short description about the topic.</p>
                                    <a href="{{url('writing/topics/1')}}" class="btn btn-primary">Select</a>
                                </div>
                            </div>

                        </div>



                        <div class="col-lg-4 mb-4">



                            <div class="card" style="width: 18rem;">
                                <img class="card-img-top" src="{{asset('userSide/assets/img/blog/slide_thumb_1.png')}}" alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title">Topic title</h5>
                                    <p class="card-text">Short description about the topic.</p>
                                    <a href="{{url('writing/topics/1')}}" class="btn btn-primary">Select</a>
                                </div>
                            </div>

                        </div>




                    </div>


                </div>
            </div>
        </div>


    </main>




@endsection
